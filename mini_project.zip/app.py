from flask import Flask, request, render_template

app = Flask(__name__)

students = {
    "814724243046": {
        "name": "gopinath .N",
        "password": "123",
        "attendance_percentage": 75,
        "details": {
            "department": "B.tech . AI&DS",
            "email": "gopinathnantheeshwaran@gmail.com",
            "parent": {"father": "R.nantheeshwaran", "mother": "N.menaga"},
            "address": "Perambalur Neduvasal Kalpadi North, Pin code-621113, Tamil Nadu, India"
        }
    },
    "814724243043": {
        "name": "fadil hammed .N",
        "password": "fadil@1",
        "attendance_percentage": 90,
        "details": {
            "department": "B.tech . AI&DS",
            "email": "fadilhammed@gmail.com",
            "parent": {"father": "nnnnnnn", "mother": "mmmmmm"},
            "address": "Erode, Tamil Nadu, India"
        }
    },
    "814724243006": {
        "name": "abishake.T",
        "password": "abi123",
        "attendance_percentage": 85,
        "details": {
            "department": "B.tech . AI&DS",
            "email": "abishake@gmail.com",
            "parent": {"father": "Yyy", "mother": "Aaa"},
            "address": "Trichy"
        }
    }
}

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    reg_no = request.form.get("reg_no")
    password = request.form.get("password")

    student = students.get(reg_no) 
    if student and student['password'] == password:
        return render_template("student_data.html", student=student)
    else:
        return "Invalid registration number or password!", 403  

if __name__ == '__main__':
    app.run(debug=True)
